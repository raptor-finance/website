<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta name=viewport content="width=device-width,initial-scale=1,shrink-to-fit=no">

    <title>Home</title>
    <link rel="icon"
          type="image/png"
          href="<?php echo get_template_directory_images_uri('/lsolo-logo.svg') ?>">
          
          <?php wp_head(); ?>
</head>
<body>